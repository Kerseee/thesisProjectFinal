#pragma once
#include <nlohmann/json.hpp>

class Foo{};
